const express = require('express');
const router = express.Router();
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = new sqlite3.Database(path.join(__dirname, 'database.db'));

// 注册路由
router.post('/register', async (req, res) => {
    const { username, password, accountType } = req.body;
    
    try {
        // 检查用户名是否已存在
        db.get('SELECT * FROM users WHERE username = ?', [username], async (err, row) => {
            if (err) {
                return res.status(500).json({ message: '数据库错误' });
            }
            
            if (row) {
                return res.status(400).json({ message: '用户名已存在' });
            }
            
            // 加密密码
            const hashedPassword = await bcrypt.hash(password, 10);
            
            // 插入新用户
            db.run(
                'INSERT INTO users (username, password, account_type) VALUES (?, ?, ?)',
                [username, hashedPassword, accountType],
                function(err) {
                    if (err) {
                        return res.status(500).json({ message: '注册失败' });
                    }
                    res.status(201).json({ message: '注册成功' });
                }
            );
        });
    } catch (error) {
        res.status(500).json({ message: '服务器错误' });
    }
});

// 登录路由
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    
    try {
        // 查找用户
        db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
            if (err) {
                return res.status(500).json({ message: '数据库错误' });
            }
            
            if (!user) {
                return res.status(401).json({ message: '用户名或密码错误' });
            }
            
            // 验证密码
            const isMatch = await bcrypt.compare(password, user.password);
            if (!isMatch) {
                return res.status(401).json({ message: '用户名或密码错误' });
            }
            
            // 生成JWT
            const token = jwt.sign(
                { id: user.id, username: user.username, accountType: user.account_type },
                process.env.SECRET_KEY || 'your-secret-key-here',
                { expiresIn: '1h' }
            );
            
            res.json({ 
                message: '登录成功',
                token,
                accountType: user.account_type 
            });
        });
    } catch (error) {
        res.status(500).json({ message: '服务器错误' });
    }
});

module.exports = router;
