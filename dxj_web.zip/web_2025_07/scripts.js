document.addEventListener('DOMContentLoaded', function() {
    // 轮播图功能
    const slides = document.querySelectorAll('.carousel-slide');
    const dotsContainer = document.querySelector('.carousel-dots');
    let currentSlideIndex = 0;
    let slideInterval;

    // 常见问题折叠功能
    const faqButtons = document.querySelectorAll('[aria-controls^="faq"]');
    faqButtons.forEach(button => {
        button.addEventListener('click', function() {
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            this.setAttribute('aria-expanded', !isExpanded);
            const answer = this.nextElementSibling;
            answer.style.display = isExpanded ? 'none' : 'block';
        });
    });

    // 创建轮播点
    slides.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.classList.add('dot');
        if (index === 0) dot.classList.add('active');
        dot.dataset.slideIndex = index;
        dotsContainer.appendChild(dot);
    });

    // 切换到指定幻灯片
    function goToSlide(index) {
        slides[currentSlideIndex].classList.remove('active');
        dotsContainer.children[currentSlideIndex].classList.remove('active');
        currentSlideIndex = index;
        slides[currentSlideIndex].classList.add('active');
        dotsContainer.children[currentSlideIndex].classList.add('active');
    }

    // 下一张幻灯片
    function nextSlide() {
        const nextIndex = (currentSlideIndex + 1) % slides.length;
        goToSlide(nextIndex);
    }

    // 事件委托处理点点击
    dotsContainer.addEventListener('click', function(e) {
        if (e.target.classList.contains('dot')) {
            clearInterval(slideInterval);
            goToSlide(parseInt(e.target.dataset.slideIndex));
            startSlideShow();
        }
    });

    // 开始自动轮播
    function startSlideShow() {
        slideInterval = setInterval(nextSlide, 5000);
    }

    // 返回顶部按钮
    document.querySelector('.fa-arrow-up').closest('button').addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // 初始化轮播
    startSlideShow();
});
