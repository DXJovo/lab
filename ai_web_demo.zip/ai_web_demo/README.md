# 农民信用贷款系统

## 项目简介
这是一个面向农民的信用贷款系统前端界面，包含用户端和管理员端功能，为农业金融提供在线服务支持。

## 功能特点
- 用户注册/登录系统
- 贷款产品浏览与申请
- 贷款审批流程
- 还款计划管理
- 数据统计与分析

## 页面结构
- `index.html`: 系统首页/登录页
- `login.html`: 用户登录页
- `register.html`: 用户注册页
- `mainContent.html`: 主内容页
- `userCenter.html`: 农户用户中心
- `admin.html`: 管理员后台

## 技术栈
- HTML5 + CSS3
- Tailwind CSS 框架
- Font Awesome 图标库
- ECharts 数据可视化

## 使用说明
1. 直接打开index.html访问系统首页
2. 点击登录/注册进入相应页面
3. 用户登录后可访问userCenter.html
4. 管理员登录后可访问admin.html

## 项目结构
```
ai_web_demo/
├── index.html        # 系统首页
├── login.html        # 登录页
├── register.html     # 注册页
├── mainContent.html  # 主内容页
├── userCenter.html   # 用户中心
├── admin.html        # 管理后台
├── IMG@1x.png        # 图片资源
├── logo.jpg          # 网站logo
└── README.md         # 项目说明
```

## 后续开发计划
- 集成Django后端
- 实现用户认证系统
- 开发贷款申请API
- 添加数据库支持
